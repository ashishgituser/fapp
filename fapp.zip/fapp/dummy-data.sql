-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.25-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for fapp
CREATE DATABASE IF NOT EXISTS `fapp` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `fapp`;


-- Dumping structure for table fapp.mstchanneluser
CREATE TABLE IF NOT EXISTS `mstchanneluser` (
  `CH_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_USER` int(11) NOT NULL,
  `ROLE` varchar(20) NOT NULL,
  `IDCHANNELUSER` varchar(50) NOT NULL,
  `PASSWORD` varchar(32) NOT NULL,
  `LOCKFLAG` bit(1) NOT NULL,
  `SUCCESS_LOGIN` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DATE_CREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`CH_ID`),
  KEY `FK__mstuser` (`ID_USER`),
  CONSTRAINT `FK__mstuser` FOREIGN KEY (`ID_USER`) REFERENCES `mstuser` (`ID_USER`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table fapp.mstchanneluser: ~1 rows (approximately)
/*!40000 ALTER TABLE `mstchanneluser` DISABLE KEYS */;
INSERT INTO `mstchanneluser` (`CH_ID`, `ID_USER`, `ROLE`, `IDCHANNELUSER`, `PASSWORD`, `LOCKFLAG`, `SUCCESS_LOGIN`, `DATE_CREATED`) VALUES
	(1, 1, 'ROLE_USER', 'ash33', 'ashish', b'1', '2018-09-18 14:30:22', '2018-09-18 14:30:23');
/*!40000 ALTER TABLE `mstchanneluser` ENABLE KEYS */;


-- Dumping structure for table fapp.mstcustomerprofile
CREATE TABLE IF NOT EXISTS `mstcustomerprofile` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` varchar(10) DEFAULT NULL,
  `users_allowed` int(3) DEFAULT NULL,
  `daily_limit` varchar(20) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- Dumping data for table fapp.mstcustomerprofile: ~0 rows (approximately)
/*!40000 ALTER TABLE `mstcustomerprofile` DISABLE KEYS */;
INSERT INTO `mstcustomerprofile` (`c_id`, `cust_id`, `users_allowed`, `daily_limit`, `first_name`, `last_name`, `address`, `city`, `country`, `zip_code`, `currency`, `date_created`) VALUES
	(5, 'dsaf', 1, '23', 'asdf', 'asd', 'asdf', 'asdf', 'asdf', '23', 'eur', '2018-09-18 17:37:45'),
	(12, '1028939', 2, '492399', 'Ashish', 'Chaudhary', 'Flat 502, Blossom Spring, Baner Pashan, Pune', 'Pune', 'India', '410034', 'inr', '2018-09-18 18:09:10');
/*!40000 ALTER TABLE `mstcustomerprofile` ENABLE KEYS */;


-- Dumping structure for table fapp.mstuser
CREATE TABLE IF NOT EXISTS `mstuser` (
  `ID_USER` int(11) NOT NULL AUTO_INCREMENT,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `ADDRESS` varchar(50) DEFAULT NULL,
  `CITY` varchar(50) DEFAULT NULL,
  `STATE` varchar(50) DEFAULT NULL,
  `COUNTRY` varchar(50) DEFAULT NULL,
  `ZIP` varchar(50) DEFAULT NULL,
  `DATE_OF_BIRTH` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `ACTIVE_FLAG` bit(1) DEFAULT NULL,
  `PHONE` varchar(50) DEFAULT NULL,
  `DATE_CREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID_USER`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table fapp.mstuser: ~1 rows (approximately)
/*!40000 ALTER TABLE `mstuser` DISABLE KEYS */;
INSERT INTO `mstuser` (`ID_USER`, `FIRST_NAME`, `LAST_NAME`, `ADDRESS`, `CITY`, `STATE`, `COUNTRY`, `ZIP`, `DATE_OF_BIRTH`, `EMAIL`, `ACTIVE_FLAG`, `PHONE`, `DATE_CREATED`) VALUES
	(1, 'Ashish', 'Chaudhary', 'Pune', 'Pune', 'Maharashtra', 'India', '410034', '30-06-1991', 'ashish.chaudhary008@gmail.com', b'1', '8527023032', '2018-09-18 14:29:50');
/*!40000 ALTER TABLE `mstuser` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
