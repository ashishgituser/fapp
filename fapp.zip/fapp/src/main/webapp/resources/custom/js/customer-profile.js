customerProfile = {

	addCustomer : function() {
		var custForm = this.convertSerilizedObjectToJson($('#custProfileForm').serializeArray());

		var status = ajaxHandler.doHandlePost('/fapp/user/customer/add', custForm);
		
		if(status) {
			window.alert('Customer profile created successfully.'); 
			$('#custProfileForm')[0].reset();
			this.getAllCustomerProfiles();
		} else {
			window.alert('There was some error while creating customer profile.');
		}
	},
	
	getAllCustomerProfiles: function() {
		
		var data = ajaxHandler.doHandleGet('/fapp/user/customer/getall');
		$('#tableData').html('');
		
		$.each(data, function(i, item) {
		    $('#tableData').append("<tr><td>"+item.cust_id+"</td><td>"+item.first_name+"</td><td>"+item.daily_limit+"</td><td>"+item.users_allowed+"</td><td>"+item.currency+"</td><td>"+item.date_created+"</td></tr>");
		});
		
		//alert(JSON.stringify(data));
	},

	convertSerilizedObjectToJson: function(serializedArray) {
		var dataObj = {};

		$(serializedArray).each(function(i, field) {
			dataObj[field.name] = field.value;
		});
		
		return JSON.stringify(dataObj);
	}
}