ajaxHandler = {
		doHandlePost: function(url, data) {
			var response = null;
			
			$.ajax({
			    url: url,
			    dataType: 'json',
			    type: 'post',
			    contentType: 'application/json',
			    data: data,
			    processData: false,
			    async: false,
			    success: function( data, textStatus, jQxhr ){
			    	response = data;
			    },
			    error: function( jqXhr, textStatus, errorThrown ){
			        response = jqXhr;
			    }
			});
			
			return response;
		},
		
		doHandleGet: function(url) {
			var response = null;
			
			$.ajax({
			    url: url,
			    dataType: 'json',
			    type: 'get',
			    processData: false,
			    async: false,
			    success: function( data, textStatus, jQxhr ){
			    	response = data;
			    },
			    error: function( jqXhr, textStatus, errorThrown ){
			        response = jqXhr;
			    }
			});
			
			return response;
		}
}