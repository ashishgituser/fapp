package com.fapp.repository;

import com.fapp.model.User;

public interface UserDao {
	User findByUserName(String username);
}
