package com.fapp.repository;

import java.util.List;

import com.fapp.model.CustomerProfile;

public interface CustomerProfileDao {
	public boolean addCustomerProfile(CustomerProfile customerProfile);
	public List<CustomerProfile> getCustomerList();
}
