package com.fapp.repository;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fapp.model.CustomerProfile;

@Transactional
@Repository
public class CustomerProfileDaoImpl implements CustomerProfileDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	private final String CUSTOMER_PROFILE_INSERT_QUERY = "insert into mstcustomerprofile(cust_id, users_allowed, daily_limit, first_name, last_name, address, city, country, zip_code, currency) values(:cust_id, :users_allowed, :daily_limit, :first_name, :last_name, :address, :city, :country, :zip_code, :currency)";
	private final String CUSTOMER_PROFILE_GET_ALL_QUERY = "select * from mstcustomerprofile";
	
	public boolean addCustomerProfile(CustomerProfile customerProfile) {
		
		Session session = null;
		boolean statusFlag = false;
		
		try {
			session = sessionFactory.getCurrentSession();
			
			SQLQuery query = session.createSQLQuery(CUSTOMER_PROFILE_INSERT_QUERY);
			
			query.setParameter("cust_id", customerProfile.getCust_id());
			query.setParameter("users_allowed", customerProfile.getUsers_allowed());
			query.setParameter("daily_limit", customerProfile.getDaily_limit());
			query.setParameter("first_name", customerProfile.getFirst_name());
			query.setParameter("last_name", customerProfile.getLast_name());
			query.setParameter("address", customerProfile.getAddress());
			query.setParameter("city", customerProfile.getCity());
			query.setParameter("country", customerProfile.getCountry());
			query.setParameter("zip_code", customerProfile.getZip_code());
			query.setParameter("currency", customerProfile.getCurrency());
			
			int status = query.executeUpdate();
			
			if(status > 0) {
				statusFlag = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusFlag;
	}

	public List<CustomerProfile> getCustomerList() {
		Session session = null;
		List<CustomerProfile> dataList = null;
		
		try {
			
			session = sessionFactory.getCurrentSession();
			
			SQLQuery query = session.createSQLQuery(CUSTOMER_PROFILE_GET_ALL_QUERY);
			
			List<Object[]> rows = query.list();
			
			if(rows.size() > 0) {
				
				dataList = new ArrayList<CustomerProfile>();
				
				for(Object[] data : rows) {
					
					CustomerProfile p = new CustomerProfile();

					p.setcId(Integer.parseInt(data[0].toString()));
					p.setCust_id(data[1].toString());
					p.setUsers_allowed(data[2].toString());
					p.setDaily_limit(data[3].toString());
					p.setFirst_name(data[4].toString());
					p.setLast_name(data[5].toString());
					p.setAddress(data[6].toString());
					p.setCity(data[7].toString());
					p.setCountry(data[8].toString());
					p.setZip_code(data[9].toString());
					p.setCurrency(data[10].toString());
					p.setDate_created(data[11].toString());
					
					dataList.add(p);
					
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dataList;
	}

}
