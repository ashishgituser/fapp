package com.fapp.repository;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fapp.model.User;
import com.fapp.model.UserRole;

@Transactional
@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public User findByUserName(String username) {

		Session session = null;
		Transaction tx = null;
		User user = null;
		UserRole userRole = null;
		
		try {
			session = getSessionFactory().getCurrentSession();
			
			SQLQuery query = session.createSQLQuery("select idchanneluser, password, lockflag, role from mstchanneluser where idchanneluser = :username and lockflag = 1");
			query.setParameter("username", username);
			List<Object[]> rows = query.list();
			
			if(rows.size() > 0) {
				
				user = new User();
				userRole = new UserRole();
				
				for(Object[] u: rows) {
					user.setUsername(u[0].toString());
					user.setPassword(u[1].toString());
					user.setEnabled(Boolean.parseBoolean(u[2].toString()));
					
					userRole.setRole(u[3].toString());
					userRole.setUserRoleId(1);
					userRole.setUser(user);
					
					user.getUserRole().add(userRole);
				}
				
			} else {
				return null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return user;
		
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

}