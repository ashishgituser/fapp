package com.fapp.model;

public class CustomerProfile {

	private int cId;
	private String cust_id;
	private String users_allowed;
	private String daily_limit;
	private String first_name;
	private String last_name;
	private String address;
	private String city;
	private String country;
	private String zip_code;
	private String currency;
	private String date_created;

	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	public String getUsers_allowed() {
		return users_allowed;
	}

	public void setUsers_allowed(String users_allowed) {
		this.users_allowed = users_allowed;
	}

	public String getDaily_limit() {
		return daily_limit;
	}

	public void setDaily_limit(String daily_limit) {
		this.daily_limit = daily_limit;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDate_created() {
		return date_created;
	}

	public void setDate_created(String date_created) {
		this.date_created = date_created;
	}

}
