package com.fapp.user.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fapp.model.CustomerProfile;
import com.fapp.service.CustomerProfileService;

@RestController
@RequestMapping( value = "/user", produces = MediaType.APPLICATION_JSON_VALUE )
public class CustomerProfileREST {

	@Autowired
	private CustomerProfileService customerProfileService;
	
	@RequestMapping(value = "/customer/add", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody boolean addCustomerProfile(@RequestBody CustomerProfile customerProfile) {
		return this.customerProfileService.addCustomerProfile(customerProfile);
	}
	
	@RequestMapping(value = "/customer/getall", method = RequestMethod.GET)
	public @ResponseBody List<CustomerProfile> getAllCustomerProfiles() {
		return this.customerProfileService.getCustomerList();
	}
}
