package com.fapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fapp.model.CustomerProfile;
import com.fapp.repository.CustomerProfileDao;

@Service
public class CustomerProfileServiceImpl implements CustomerProfileService {

	@Autowired
	private CustomerProfileDao customerProfileDao;
	
	public boolean addCustomerProfile(CustomerProfile customerProfile) {
		return this.customerProfileDao.addCustomerProfile(customerProfile);
	}

	public List<CustomerProfile> getCustomerList() {
		return this.customerProfileDao.getCustomerList();
	}

}
