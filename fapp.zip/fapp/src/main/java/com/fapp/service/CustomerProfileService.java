package com.fapp.service;

import java.util.List;

import com.fapp.model.CustomerProfile;

public interface CustomerProfileService {
	public boolean addCustomerProfile(CustomerProfile customerProfile);
	public List<CustomerProfile> getCustomerList();
}
